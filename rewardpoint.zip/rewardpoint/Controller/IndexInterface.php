<?php
/**
 * Copyright (c) 2018 BrainActs Commerce OÜ, All rights reserved.
 * See LICENSE.txt for license details.
 */

namespace BrainActs\RewardPoints\Controller;

/**
 * Interface IndexInterface
 *
 * @author BrainActs Core Team <support@brainacts.com>
 * @api
 */
interface IndexInterface extends \Magento\Framework\App\ActionInterface
{

}
