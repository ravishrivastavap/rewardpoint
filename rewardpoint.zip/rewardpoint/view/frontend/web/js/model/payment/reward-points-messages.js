/*
 * Copyright (c) 2018 BrainActs Commerce OÜ, All rights reserved.
 * See LICENSE.txt for license details.
 */
define(
    [
        'Magento_Ui/js/model/messages'
    ],
    function (Messages) {
        'use strict';

        return new Messages();
    }
);
