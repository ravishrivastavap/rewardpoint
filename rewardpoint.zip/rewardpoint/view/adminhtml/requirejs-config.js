/*
 * Copyright (c) 2018 BrainActs Commerce OÜ, All rights reserved.
 * See LICENSE.txt for license details.
 */

var config = {
    map: {
        '*': {
            "RewardPoints":'BrainActs_RewardPoints/js/points'
        }
    }
};
